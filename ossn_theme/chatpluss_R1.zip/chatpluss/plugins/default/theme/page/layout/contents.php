<?php
/**
 
 */
 ?>
<div class="container">
       <div class="row">
       		<div class="ossn-layout-contents">
            	 <?php echo ossn_plugin_view('theme/page/elements/system_messages'); ?>
				 <?php echo $params['content']; ?>
             </div>    
        </div> 
	       <?php echo ossn_plugin_view('theme/page/elements/footer'); ?>             
</div>
