<?php
/**
 

 */
?>

<div class="ossn-layout-startup">
	<div class="container">
		<div class="row">
            <?php echo ossn_plugin_view('theme/page/elements/system_messages'); ?>        
			<div class="ossn-home-container">
				<div class="inner">
					<?php echo $params['content']; ?>
				</div>
			</div>
		</div>
		
		<?php echo ossn_plugin_view('theme/page/elements/footer'); ?>
	</div>
</div>


<?php
/**
 
 
<script>$(window).ready(function(){$('body').addClass('ossn-layout-startup-background');}); </script>
*/
?>
