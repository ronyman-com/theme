<?php
/**
 ronyman.com
 */
?>
<div class="ossn-profile-module-item">
    <div class="module-title">
        <?php echo $params['title']; ?>
    </div>
    <div class="contents">
        <?php echo $params['contents']; ?>
    </div>
</div>